#ifndef COORD_H
#define COORD_H

typedef struct _une_coord{
	float lon; //Longitude decimale
	float lat; //Latitude decimale
}Une_coord;
#endif